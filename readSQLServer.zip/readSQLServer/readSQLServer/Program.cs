﻿using System;
using System.Data.SqlClient;

namespace SqlServer
{
    class DbConnection
    {
        public static void main(String[] args)
        {
            SqlConnection db = new SqlConnection(@"Data Source=localhost; Initial Catalog=NLHospital; Integrated Security=false;user id=" + "pcannell" + ";password=" + "purpleunicornsdancearoundtheOasis12#");

        }
    }

}
